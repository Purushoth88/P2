
public class BancoException extends Exception {
	
	public BancoException(String msg){
		super(msg);
	}
	
	public BancoException(){
		super();
	}
}
