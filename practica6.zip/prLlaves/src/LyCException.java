
public class LyCException extends Exception{

	public LyCException(){
		super("Datos invalidos");
	}
	
	public LyCException(String msg){
		super(msg);
	}
	
}
