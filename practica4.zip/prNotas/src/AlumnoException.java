
public class AlumnoException extends Exception {
	
	public AlumnoException(){
		super("ERROR. Calicicaion no numerica ");
	}
	
	public AlumnoException(String msg){
		super(msg);
	}
}
