import java.net.ProxySelector;
import java.util.*;


public class Indice {
	
	protected SortedMap<String, SortedSet<Titulo>> kwic;
	protected String separadores;
	
	public Indice(String sep){
		if(sep == null || sep.isEmpty()) throw new IllegalArgumentException();
		
		separadores = "["+sep+"]";
		kwic = new TreeMap<String, SortedSet<Titulo>>();
	}
	
	
	public Indice(String sep, Collection<String> col){
		this(sep);
		agregarTitulo(col);
	}
	
	
	public void agregarTitulo(String t){
		Scanner sc = new Scanner(t);
		sc.useDelimiter(separadores);
		while(sc.hasNext()){
			String palabra = sc.next();
			if(kwic.containsKey(palabra)){
				kwic.get(palabra).add(new Titulo(t));
			}else{
				SortedSet<Titulo> set = new TreeSet<Titulo>();
				Titulo titulo = new Titulo(t);
				set.add(titulo);
				kwic.put(palabra, set);
			}
		}
		sc.close();
	}
	
	
	public void agregarTitulo(Collection<String> titulos){
		if(titulos==null) throw new IllegalArgumentException("Colecion null");
		
		for(String tit : titulos){
			
			agregarTitulo(tit);
			
		}
	}
	
	public String presentaIndice(){
		String salida ="";
		for(String ind : kwic.keySet()){
			if(kwic.containsKey(ind)){
				salida+=ind.toUpperCase()+"\n";
				for(Titulo t: kwic.get(ind)){
					salida+=t.replace(ind)+"\n";
				}
				salida+="\n";
			}
		}
		return salida;
	}
	
}
