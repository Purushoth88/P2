
import java.util.Collection;

import java.util.Scanner;

import java.util.SortedSet;

import java.util.TreeSet;


public class IndiceSignificativas extends Indice{

	private SortedSet<String> noSignificativas;

	public IndiceSignificativas(String sep, Collection<String> set){
		super(sep);
		noSignificativas = new TreeSet<String>();
		for(String str : set){
			noSignificativas.add(str.toLowerCase());
		}

	}

	public IndiceSignificativas(String sep,Collection<String> col,Collection<String> set){
		this(sep,set);
		agregarTitulo(col);

	}

	@Override
	public void agregarTitulo(Collection<String> titulos){
		if(titulos==null) 
			throw new IllegalArgumentException("Colecion null");

		for(String tit : titulos){
			agregarTitulo(tit.toLowerCase());
		}
	}

	@Override
	public void agregarTitulo(String titulo){
		Scanner sc = new Scanner(titulo);
		sc.useDelimiter(separadores);
		while(sc.hasNext()){
			String pal = sc.next();
			if(!noSignificativas.contains(pal) && kwic.containsKey(pal)){
				kwic.get(pal).add(new Titulo(titulo));
			}else if(!noSignificativas.contains(pal) && !kwic.containsKey(pal)){
				SortedSet<Titulo> set = new TreeSet<Titulo>();
				Titulo tit = new Titulo(titulo);
				set.add(tit);
				kwic.put(pal, set);
			}
		}

	}


}



