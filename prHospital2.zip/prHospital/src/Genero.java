
public enum Genero {
	MUJER,HOMBRE
}
