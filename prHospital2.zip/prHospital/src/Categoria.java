
public enum Categoria {
	RESIDENTE,ADJUNTO,INTERINO
}
